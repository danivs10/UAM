The missing files needed to execute correctly the application are generated
my executing the makefile, with the command "make all"